package com.cognizant.service;

import com.cognizant.model.Assessment;

public interface AssessmentService {
	public boolean insertAssessment(Assessment assessment);
	public int getAid();
	
}
